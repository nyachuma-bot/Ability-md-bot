# Ability-md-bot
WhatsApp Multi-Device bot iliyotengenezwa kwa Baileys MD, ikiwa na commands za group na matumizi ya kila siku.
